const express = require('express');
const admin = require('../firebase/firebase');
const fetch = require('node-fetch');
const router = express.Router();

router.post('/', async (req, res) => {
  const evento = req.body;

  if (evento.action !== 'payment.created' && evento.action !== 'payment.updated') {
    return res.sendStatus(200);
  }

  const pagamentoId = evento.data?.id;

  try {
    const mpRes = await fetch(`https://api.mercadopago.com/v1/payments/${pagamentoId}`, {
      headers: {
        Authorization: `Bearer ${process.env.MP_TOKEN}`
      }
    });
    const pagamento = await mpRes.json();

    if (pagamento.status === 'approved') {
      const email = pagamento.payer?.email || 'desconhecido';
      const valor = pagamento.transaction_amount;

      const userRef = admin.firestore().collection('users').doc(email);
      await userRef.set({ saldo: admin.firestore.FieldValue.increment(valor) }, { merge: true });

      console.log(`Pagamento aprovado para ${email}: R$ ${valor}`);
    }

    res.sendStatus(200);
  } catch (err) {
    console.error('Erro no webhook:', err);
    res.sendStatus(500);
  }
});

module.exports = router;