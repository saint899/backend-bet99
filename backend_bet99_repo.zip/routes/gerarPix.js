const express = require('express');
const axios = require('axios');
const router = express.Router();

router.post('/', async (req, res) => {
  const { valor, descricao, email } = req.body;

  if (!valor || !descricao || !email) {
    return res.status(400).json({ error: 'Campos obrigatórios: valor, descricao, email' });
  }

  try {
    const response = await axios.post('https://api.mercadopago.com/v1/payments', {
      transaction_amount: parseFloat(valor),
      description: descricao,
      payment_method_id: 'pix',
      payer: {
        email: email
      }
    }, {
      headers: {
        Authorization: `Bearer ${process.env.MP_TOKEN}`,
        'Content-Type': 'application/json'
      }
    });

    const { id, point_of_interaction } = response.data;

    res.json({
      id,
      qr_code_base64: point_of_interaction.transaction_data.qr_code_base64,
      qr_code: point_of_interaction.transaction_data.qr_code
    });
  } catch (error) {
    console.error('Erro ao gerar PIX:', error.response?.data || error.message);
    res.status(500).json({ error: 'Erro ao gerar cobrança PIX' });
  }
});

module.exports = router;