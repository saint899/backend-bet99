require('dotenv').config();
const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');

const gerarPix = require('./routes/gerarPix');
const webhook = require('./routes/webhook');

const app = express();
const PORT = process.env.PORT || 3001;

app.use(cors());
app.use(bodyParser.json());

app.use('/gerar-pix', gerarPix);
app.use('/webhook', webhook);

app.get('/', (req, res) => res.send('Backend Bet99 ativo.'));

app.listen(PORT, () => console.log(`Servidor rodando na porta ${PORT}`));